#ifndef __SYS_H
#define __SYS_H
#ifdef __cplusplus
extern "C"{
#endif
#include "main.h"



void RCC_SYSTEMSCLK_CONFIG(void);

#ifdef __cplusplus
}
#endif
#endif
