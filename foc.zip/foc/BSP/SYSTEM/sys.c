#include "../BSP/SYSTEM/sys.h"
/*1.HSE,2.HSI */
#define CLOCKSOURCE 1

#if CLOCKSOURCE == 2
/*
* name  : RCC_HSI_SYSTEMSCLK_CONFIG
* param : none
* found : 用HSI配置系统时钟 168M
*/
void RCC_SYSTEMSCLK_CONFIG(void)
{
	/*系统时钟源配置*/
	RCC_OscInitTypeDef RCC_OscInitTypeDefStructure ={
		.HSIState = RCC_HSI_ON,
		.HSICalibrationValue  = RCC_HSICALIBRATION_DEFAULT,
		.OscillatorType = RCC_OSCILLATORTYPE_HSI,
		.PLL.PLLSource = RCC_PLLSOURCE_HSI,
		.PLL.PLLState = RCC_PLL_ON,
		/*voc频率为2M,HSI:16M*/
		.PLL.PLLM = 8 ,  
		/*pll时钟为168M*/
		.PLL.PLLP = RCC_PLLP_DIV2,
		.PLL.PLLN = 84*2
	}; 
	HAL_RCC_OscConfig(&RCC_OscInitTypeDefStructure);
	
	/*系统时钟树配置 系统时钟，AHB总线时钟，APB1时钟，APB2时钟*/
	RCC_ClkInitTypeDef RCC_ClkInitTypeDefStructure = {
		
		.ClockType = RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2,   
		.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK ,
		.AHBCLKDivider = RCC_SYSCLK_DIV1,
		.APB1CLKDivider = RCC_HCLK_DIV4,
		.APB2CLKDivider = RCC_HCLK_DIV2
	};
	HAL_RCC_ClockConfig(&RCC_ClkInitTypeDefStructure,FLASH_LATENCY_5);
	
	/*更新时钟*/
	SystemCoreClockUpdate();
	HAL_SYSTICK_Config(SystemCoreClock / (1000U / uwTickFreq));
}

#elif CLOCKSOURCE == 1
/*
* name  : RCC_HSI_SYSTEMSCLK_CONFIG
* param : none
* found : 用HSE配置系统时钟 168M
*/
void RCC_SYSTEMSCLK_CONFIG(void)
{
	/*系统时钟源配置*/
	RCC_OscInitTypeDef RCC_OscInitTypeDefStructure ={
		.HSEState = RCC_HSE_ON,
		.OscillatorType = RCC_OSCILLATORTYPE_HSE,
		.PLL.PLLSource = RCC_PLLSOURCE_HSE,
		.PLL.PLLState = RCC_PLL_ON,
		/*voc频率为2M,HSE: 8M*/
		.PLL.PLLM = 4 ,
		/*pll时钟为168M*/
		.PLL.PLLP = RCC_PLLP_DIV2,
		.PLL.PLLN = 84*2
	}; 
	HAL_RCC_OscConfig(&RCC_OscInitTypeDefStructure);
	
	/*系统时钟树配置 系统时钟，AHB总线时钟，APB1时钟，APB2时钟*/
	RCC_ClkInitTypeDef RCC_ClkInitTypeDefStructure = {
		
		.ClockType = RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2,   
		.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK ,
		.AHBCLKDivider = RCC_SYSCLK_DIV1,
		.APB1CLKDivider = RCC_HCLK_DIV4,
		.APB2CLKDivider = RCC_HCLK_DIV2
	};
	HAL_RCC_ClockConfig(&RCC_ClkInitTypeDefStructure,FLASH_LATENCY_5);
	
	
	/*更新时钟*/
	SystemCoreClockUpdate();
	HAL_SYSTICK_Config(SystemCoreClock / (1000U / uwTickFreq));
}
#endif
