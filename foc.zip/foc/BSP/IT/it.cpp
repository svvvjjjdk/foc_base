#include "../BSP/IT/it.h"
#include "../BSP/TIM/tim.h"
#include "../BSP/ADC/adc.h"
#include "../BSP/USART/usart.h"
#include "../SDK/foc_math/foc_math.h"
#include "delay.h"
#include "gui_guider.h"
#include <cstring>

/***********��ʱ��************/
extern "C" void TIM3_IRQHandler(void)
{
 HAL_TIM_IRQHandler(&htim3);
}

extern "C" void TIM7_IRQHandler(void)
{
	HAL_TIM_IRQHandler(&htim7);
}

extern "C" void TIM1_CC_IRQHandler(void)
{
	HAL_TIM_IRQHandler(&htim1);
}

extern "C" void TIM5_IRQHandler(void)
{
	HAL_TIM_IRQHandler(&htim5);
}

extern "C" void TIM2_IRQHandler(void)
{
	HAL_TIM_IRQHandler(&htim2);
}
/****�ص�****/
extern FOC foc1;
D_Q_T Idq = {0,0};
D_Q_T Udq = {0,0};

extern "C" void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	/*������*/
	if(htim->Instance == TIM3)
	{
		/*��ʱ��*/
		if(htim3.Instance->CR1&(0x01<<4))
		{
			foc1.encoder_cnt--;
		}
		/*˳ʱ��*/
		else
		{
			foc1.encoder_cnt++;
		}
	}
	/*����,��ʱ������200us,5KHz*/
	 else if(htim->Instance == TIM7)
	{
			if(foc1.pos_zero_flag ==1)
			{
				/*�ٶȻ� 5kHz*/
			  foc1.Speed_feedback_road(foc1.speed_targe,Idq);
				/*������������·*/
				foc1.I_feedback_road(Idq,Udq);
				
			}
			else 
			{
					foc1.Find_Zero();
					
			}
	}
	else if(htim->Instance == TIM5)
	{
		if(!(flag_delay--))
		{
			HAL_TIM_Base_Stop_IT(&htim5);
			flag_delay = 0;
		}
	}
	else if(htim->Instance == TIM2)
	{
		uart_printf("%d\n",int(foc1.Speed_Rpm));
	}
}

extern "C" void HAL_TIM_OC_DelayElapsedCallback(TIM_HandleTypeDef *htim)
{
	/*SVPWM���㣬pwmƵ��20KHz*/
	if(htim->Instance == TIM1)
	{
			if(foc1.pos_zero_flag ==1)
			{
				foc1.Angle =  foc1.Get_angle();
				foc1.openloop_road(&Udq);
			}
	}
}
/**************�ⲿ�ж�****************/
extern "C" void EXTI2_IRQHandler(void)
{
	if(__HAL_GPIO_EXTI_GET_IT(GPIO_PIN_2))
	{
		__HAL_GPIO_EXTI_CLEAR_IT(GPIO_PIN_2);
		if(foc1.speed_targe == 0)
		{
			foc1.speed_targe =500 ;
		}
		else
			foc1.speed_targe =0 ;
	}
}

extern "C" void EXTI9_5_IRQHandler(void)
{
	if(__HAL_GPIO_EXTI_GET_IT(GPIO_PIN_6))
	{
		__HAL_GPIO_EXTI_CLEAR_IT(GPIO_PIN_6);
		if(foc1.pos_zero_flag == 0)
		{
			__HAL_TIM_SetCounter(&htim3,0);
			HAL_TIM_PWM_Start_IT(&htim1,TIM_CHANNEL_4);
			foc1.pos_zero_flag = 1;
		}
		
	}
}
/***************ADC******************/
int32_t U_offset = 0,V_offset = 0;
extern "C" void DMA2_Stream2_IRQHandler(void)
{
	HAL_DMA_IRQHandler(&hadc2_dma);
}
extern "C" void ADC_IRQHandler(void)
{
	HAL_ADC_IRQHandler(&hadc2);
}

extern "C" void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc)
{
		static int16_t i = 0;
		if(i >= 100)
		{
			HAL_ADC_Stop_DMA(&hadc2);
			U_offset /= i;
			V_offset /= i;
			Iabc_ADC_JInit();
//			HAL_TIM_Base_Start(&htim7);
		}
		else if(i>=0)
		{
			U_offset += adc_dmabuffer[0];
			V_offset += adc_dmabuffer[1];
			i++;
		}
}
extern "C" void HAL_ADCEx_InjectedConvCpltCallback(ADC_HandleTypeDef* hadc)
{
		
		const float conv = 8.0586E-4f;  // 3.3/4095
		foc1.Iabc.A = (((int32_t)HAL_ADCEx_InjectedGetValue(&hadc2,1) - U_offset) * conv ) / 0.12f;
		foc1.Iabc.B = (((int32_t)HAL_ADCEx_InjectedGetValue(&hadc2,2) - V_offset) * conv ) / 0.12f;
	  foc1.Iabc.C = -(foc1.Iabc.A +  foc1.Iabc.B);
}