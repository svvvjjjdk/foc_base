#include "../BSP/ADC/adc.h"

ADC_HandleTypeDef hadc2;
DMA_HandleTypeDef hadc2_dma;
uint16_t adc_dmabuffer[2] = {0};
/*����������W:PA3,ADC2_IN3,V:PA6,ADC12_IN6,U:PB0,ADC1_IN8*/
void Iabc_ADC_JInit(void)
{
	HAL_DMA_DeInit(&hadc2_dma);
	HAL_NVIC_DisableIRQ(DMA2_Stream2_IRQn);
	
	ADC_InjectionConfTypeDef sConfigInjected = {0};
	
  hadc2.Instance = ADC2;
  hadc2.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4; //21MHz
  hadc2.Init.Resolution = ADC_RESOLUTION_12B;
  hadc2.Init.ScanConvMode = ENABLE;
  hadc2.Init.ContinuousConvMode = DISABLE;
  hadc2.Init.DiscontinuousConvMode = DISABLE;
  hadc2.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc2.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc2.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc2.Init.NbrOfConversion = 0;
  hadc2.Init.DMAContinuousRequests = DISABLE;
  hadc2.Init.EOCSelection = ADC_EOC_SEQ_CONV;
  if (HAL_ADC_Init(&hadc2) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigInjected.InjectedChannel = ADC_CHANNEL_8;
  sConfigInjected.InjectedRank = 1;
  sConfigInjected.InjectedNbrOfConversion = 2;
  sConfigInjected.InjectedSamplingTime = ADC_SAMPLETIME_28CYCLES;
  sConfigInjected.ExternalTrigInjecConvEdge = ADC_EXTERNALTRIGINJECCONVEDGE_RISING;
  sConfigInjected.ExternalTrigInjecConv = ADC_EXTERNALTRIGINJECCONV_T1_CC4;
  sConfigInjected.AutoInjectedConv = DISABLE;
  sConfigInjected.InjectedDiscontinuousConvMode = DISABLE;
  sConfigInjected.InjectedOffset = 0;
  if (HAL_ADCEx_InjectedConfigChannel(&hadc2, &sConfigInjected) != HAL_OK)
  {
    Error_Handler();
  }
  
  sConfigInjected.InjectedChannel = ADC_CHANNEL_6;
  sConfigInjected.InjectedRank = 2;
  if (HAL_ADCEx_InjectedConfigChannel(&hadc2, &sConfigInjected) != HAL_OK)
  {
    Error_Handler();
  }

//  sConfigInjected.InjectedChannel = ADC_CHANNEL_3;
//  sConfigInjected.InjectedRank = 3;
//  if (HAL_ADCEx_InjectedConfigChannel(&hadc2, &sConfigInjected) != HAL_OK)
//  {
//    Error_Handler();
//  }
	HAL_NVIC_SetPriority(ADC_IRQn,2,3);
	HAL_NVIC_EnableIRQ(ADC_IRQn);
	
	HAL_ADCEx_InjectedStart_IT(&hadc2);
}

void Iabc_ADC_Init(void)
{
	__HAL_RCC_ADC2_CLK_ENABLE();
	__HAL_RCC_GPIOA_CLK_ENABLE();
	__HAL_RCC_GPIOB_CLK_ENABLE();
	__HAL_RCC_DMA2_CLK_ENABLE();

	ADC_InjectionConfTypeDef sInjectChannelConfig = {0};
	
	GPIO_InitTypeDef GPIO_InitTypeDefStructre={0};
	GPIO_InitTypeDefStructre.Pin = GPIO_PIN_3 | GPIO_PIN_6 ;
	GPIO_InitTypeDefStructre.Mode = GPIO_MODE_ANALOG;
	GPIO_InitTypeDefStructre.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(GPIOA,&GPIO_InitTypeDefStructre);
	
	GPIO_InitTypeDefStructre.Pin = GPIO_PIN_0 ;
	HAL_GPIO_Init(GPIOB,&GPIO_InitTypeDefStructre);
	
  ADC_ChannelConfTypeDef sConfig = {0};

  hadc2.Instance = ADC2;
  hadc2.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;
  hadc2.Init.Resolution = ADC_RESOLUTION_12B;
  hadc2.Init.ScanConvMode = ENABLE;
  hadc2.Init.ContinuousConvMode = ENABLE;
  hadc2.Init.DiscontinuousConvMode = DISABLE;
  hadc2.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc2.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc2.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc2.Init.NbrOfConversion = 2;
  hadc2.Init.DMAContinuousRequests = ENABLE;
  hadc2.Init.EOCSelection = ADC_EOC_SEQ_CONV;
  if (HAL_ADC_Init(&hadc2) != HAL_OK)
  {
    Error_Handler();
  }
  sConfig.Channel = ADC_CHANNEL_8;
  sConfig.Rank = 1;
  sConfig.SamplingTime = ADC_SAMPLETIME_28CYCLES;
  if (HAL_ADC_ConfigChannel(&hadc2, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  
  sConfig.Channel = ADC_CHANNEL_6;
  sConfig.Rank = 2;
  if (HAL_ADC_ConfigChannel(&hadc2, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
	hadc2.Instance = ADC2;
	hadc2.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV4;		//ʱ��36M
	hadc2.Init.Resolution = ADC_RESOLUTION_12B;							//12λ����
	hadc2.Init.ScanConvMode =  ENABLE;											//ʹ��ɨ��ģʽ
	hadc2.Init.DataAlign =  ADC_DATAALIGN_RIGHT;						//�����Ҷ���
	hadc2.Init.DMAContinuousRequests = DISABLE;							//DMAת������ʧ��,DMA����Թ�����
	hadc2.Init.ContinuousConvMode = DISABLE;								//����ת��ʧ��
	hadc2.Init.NbrOfConversion = 0;													//ɨ��ģʽ�¹���ͨ������
	hadc2.Init.EOCSelection = ADC_EOC_SEQ_CONV;					    //ȫ����ɺ󴥷�E0C
	hadc2.Init.ExternalTrigConv = ADC_SOFTWARE_START;				//��������
	hadc2.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE; //�޴�������
	
	hadc2_dma.Instance = DMA2_Stream2;
	hadc2_dma.Init.Channel = DMA_CHANNEL_1;
	hadc2_dma.Init.Direction = DMA_PERIPH_TO_MEMORY;
	hadc2_dma.Init.MemInc = DMA_MINC_ENABLE;
	hadc2_dma.Init.PeriphInc = DMA_PINC_DISABLE; 
	hadc2_dma.Init.MemDataAlignment = DMA_MDATAALIGN_HALFWORD;
	hadc2_dma.Init.PeriphDataAlignment = DMA_PDATAALIGN_HALFWORD;
	hadc2_dma.Init.Mode = DMA_CIRCULAR;
	hadc2_dma.Init.Priority = DMA_PRIORITY_MEDIUM;
	__HAL_LINKDMA(&hadc2,DMA_Handle,hadc2_dma);
	if(HAL_DMA_Init(&hadc2_dma) != HAL_OK)
	{
		Error_Handler();
	}
	HAL_NVIC_SetPriority(DMA2_Stream2_IRQn,3,3);
	HAL_NVIC_EnableIRQ(DMA2_Stream2_IRQn);
	HAL_ADC_Start_DMA(&hadc2,(uint32_t*)adc_dmabuffer,2);
}