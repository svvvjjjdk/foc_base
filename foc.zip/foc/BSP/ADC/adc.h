#ifndef __ADC_H
#define __ADC_H
#ifdef __cplusplus
extern "C"{
#endif
#include "main.h"

void Iabc_ADC_Init(void);
void Iabc_ADC_JInit(void);

extern ADC_HandleTypeDef hadc2;
extern DMA_HandleTypeDef hadc2_dma;
extern uint16_t adc_dmabuffer[];
#ifdef __cplusplus
}
#endif
#endif
