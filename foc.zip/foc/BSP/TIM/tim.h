#ifndef __TIM_H
#define __TIM_H
#ifdef __cplusplus
extern "C"{
#endif
#include "main.h"

void TIM1_Init(void);
void TIM3_Init(void);
void TIM7_Init(void);
void TIM5_Init(void);
void TIM2_Init(void);
	
extern TIM_HandleTypeDef htim1;
extern TIM_HandleTypeDef htim7;
extern TIM_HandleTypeDef htim3;
extern TIM_HandleTypeDef htim5;
extern TIM_HandleTypeDef htim2;
#ifdef __cplusplus
}
#endif
#endif
