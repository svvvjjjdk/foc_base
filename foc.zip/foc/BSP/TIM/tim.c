#include "../BSP/TIM/tim.h"

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim7;
TIM_HandleTypeDef htim5;
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim2;
/*psc = 1-1 , arr = 4200-1,20kHz*/
/*�����������*/
void TIM1_Init(void)
{
	__HAL_RCC_TIM1_CLK_ENABLE();
	__HAL_RCC_GPIOA_CLK_ENABLE();
	__HAL_RCC_GPIOB_CLK_ENABLE();
	
	TIM_ClockConfigTypeDef sClockSourceConfig = {0};
	TIM_OC_InitTypeDef sConfigOc = {0};
	TIM_BreakDeadTimeConfigTypeDef sBreakConfig = {0};
	
	GPIO_InitTypeDef GPIO_InitTypeDefStructre={0};
	GPIO_InitTypeDefStructre.Pin = GPIO_PIN_8 | GPIO_PIN_9 | GPIO_PIN_10 | GPIO_PIN_11;
	GPIO_InitTypeDefStructre.Mode = GPIO_MODE_AF_PP;
	GPIO_InitTypeDefStructre.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_InitTypeDefStructre.Alternate = GPIO_AF1_TIM1;
	GPIO_InitTypeDefStructre.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(GPIOA,&GPIO_InitTypeDefStructre);
	
	GPIO_InitTypeDefStructre.Pin = GPIO_PIN_13 | GPIO_PIN_14 | GPIO_PIN_15;
	HAL_GPIO_Init(GPIOB,&GPIO_InitTypeDefStructre);
	
	htim1.Instance = TIM1;
	htim1.Init.Prescaler = 1-1;
	htim1.Init.Period  = 4200-1;
	htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
	htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV2;
	htim1.Init.CounterMode = TIM_COUNTERMODE_CENTERALIGNED2;
	htim1.Init.RepetitionCounter = 1;
	if(HAL_TIM_Base_Init(&htim1)!=HAL_OK)
	{
		Error_Handler();
	}

	sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
	if(HAL_TIM_ConfigClockSource(&htim1,&sClockSourceConfig)!=HAL_OK)
	{
		Error_Handler();
	}

	/*PWM����*/
	if(HAL_TIM_PWM_Init(&htim1)!=HAL_OK)
	{
		Error_Handler();
	}
	
	sConfigOc.OCMode = TIM_OCMODE_PWM1;
	sConfigOc.Pulse =0;
	sConfigOc.OCPolarity  = TIM_OCPOLARITY_HIGH;
	sConfigOc.OCNPolarity  = TIM_OCNPOLARITY_HIGH;
	sConfigOc.OCIdleState  =  TIM_OCIDLESTATE_RESET;
	sConfigOc.OCNIdleState = TIM_OCNIDLESTATE_RESET;
	sConfigOc.OCFastMode = TIM_OCFAST_DISABLE;
	if(HAL_TIM_PWM_ConfigChannel(&htim1,&sConfigOc,TIM_CHANNEL_1)!=HAL_OK)
	{
		Error_Handler();
	}
	if(HAL_TIM_PWM_ConfigChannel(&htim1,&sConfigOc,TIM_CHANNEL_2)!=HAL_OK)
	{
		Error_Handler();
	}
	if(HAL_TIM_PWM_ConfigChannel(&htim1,&sConfigOc,TIM_CHANNEL_3)!=HAL_OK)
	{
		Error_Handler();
	}
	sConfigOc.OCMode = TIM_OCMODE_PWM2;
	sConfigOc.Pulse =3640; //4199*0.86
	if(HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOc, TIM_CHANNEL_4)!=HAL_OK)
	{
		Error_Handler();
	}
	sBreakConfig.OffStateIDLEMode = TIM_OSSI_ENABLE;
	sBreakConfig.OffStateRunMode = TIM_OSSR_ENABLE;
	sBreakConfig.DeadTime	 = 67;/*800ns*/
	sBreakConfig.BreakState = TIM_BREAK_DISABLE;
	sBreakConfig.LockLevel = TIM_LOCKLEVEL_OFF;
	HAL_TIMEx_ConfigBreakDeadTime(&htim1,&sBreakConfig);
	
	__HAL_TIM_CLEAR_FLAG(&htim1,TIM_FLAG_UPDATE);
	
	HAL_NVIC_SetPriority(TIM1_CC_IRQn,1,0);
	HAL_NVIC_EnableIRQ(TIM1_CC_IRQn);
	

	HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_1);
	HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_2);
	HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_3);
	HAL_TIMEx_PWMN_Start(&htim1,TIM_CHANNEL_1);
	HAL_TIMEx_PWMN_Start(&htim1,TIM_CHANNEL_2);
	HAL_TIMEx_PWMN_Start(&htim1,TIM_CHANNEL_3);

}


/*������ʱ��200us*/
void TIM7_Init(void)
{
	/*������APB1��,Ƶ��/2*/
	__HAL_RCC_TIM7_CLK_ENABLE();
	 
	htim7.Instance = TIM7;
	htim7.Init.Prescaler = 168-1;
	htim7.Init.Period = 100-1;
	htim7.Init.AutoReloadPreload =  TIM_AUTORELOAD_PRELOAD_DISABLE;
	htim7.Init.CounterMode = TIM_COUNTERMODE_UP;
	
	if(HAL_TIM_Base_Init(&htim7) != HAL_OK)
	{
		Error_Handler();
	}
	__HAL_TIM_CLEAR_FLAG(&htim7,TIM_FLAG_UPDATE);
	
	HAL_NVIC_SetPriority(TIM7_IRQn,2,2);
	HAL_NVIC_EnableIRQ(TIM7_IRQn);
	
	__HAL_TIM_ENABLE_IT(&htim7, TIM_IT_UPDATE);
}

void TIM5_Init(void)
{
	/*������APB1��,Ƶ��/2*/
	__HAL_RCC_TIM5_CLK_ENABLE();
	 
	htim5.Instance = TIM5;
	htim5.Init.Prescaler = 1-1;
	htim5.Init.Period = 84-1;
	htim5.Init.AutoReloadPreload =  TIM_AUTORELOAD_PRELOAD_DISABLE;
	htim5.Init.CounterMode = TIM_COUNTERMODE_UP;
	
	if(HAL_TIM_Base_Init(&htim5) != HAL_OK)
	{
		Error_Handler();
	}
	__HAL_TIM_CLEAR_FLAG(&htim5,TIM_FLAG_UPDATE);
	
	HAL_NVIC_SetPriority(TIM5_IRQn,3,3);
	HAL_NVIC_EnableIRQ(TIM5_IRQn);
	
	HAL_TIM_Base_Start_IT(&htim5);
}

/*�ٶȲⶨ������,��ʱ�������,˳ʱ��Ӽ���*/
void TIM3_Init(void)
{
	__HAL_RCC_TIM3_CLK_ENABLE();
	__HAL_RCC_GPIOC_CLK_ENABLE();
	
	TIM_Encoder_InitTypeDef sEncoderConfig = {0};
	
	GPIO_InitTypeDef GPIO_InitTypeDefStructure ={0};
	GPIO_InitTypeDefStructure.Mode = GPIO_MODE_AF_PP;
	GPIO_InitTypeDefStructure.Pin = GPIO_PIN_6 | GPIO_PIN_7;
	GPIO_InitTypeDefStructure.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	GPIO_InitTypeDefStructure.Alternate = GPIO_AF2_TIM3;
	HAL_GPIO_Init(GPIOC,&GPIO_InitTypeDefStructure);

	htim3.Instance = TIM3;
	htim3.Init.Prescaler = 1-1;
	htim3.Init.Period = 4000-1;
	htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	htim3.Init.AutoReloadPreload = TIM_AUTOMATICOUTPUT_DISABLE;
	
	
	sEncoderConfig.EncoderMode = TIM_ENCODERMODE_TI12;
	sEncoderConfig.IC1Filter = 10;
	sEncoderConfig.IC1Polarity = TIM_ENCODERINPUTPOLARITY_RISING;
	sEncoderConfig.IC1Prescaler = TIM_ICPSC_DIV1;
	sEncoderConfig.IC1Selection = TIM_ICSELECTION_DIRECTTI;
	sEncoderConfig.IC2Filter = 10;
	sEncoderConfig.IC2Polarity = TIM_ENCODERINPUTPOLARITY_RISING;
	sEncoderConfig.IC2Prescaler = TIM_ICPSC_DIV1;
	sEncoderConfig.IC2Selection = TIM_ICSELECTION_DIRECTTI;
	HAL_TIM_Encoder_Init(&htim3,&sEncoderConfig);
	__HAL_TIM_CLEAR_FLAG(&htim3,TIM_FLAG_UPDATE);
	__HAL_TIM_ENABLE_IT(&htim3, TIM_IT_UPDATE);
	
	HAL_NVIC_SetPriority(TIM3_IRQn,3,0);
	HAL_NVIC_EnableIRQ(TIM3_IRQn);

	HAL_TIM_Encoder_Start(&htim3,TIM_CHANNEL_1);
	HAL_TIM_Encoder_Start(&htim3,TIM_CHANNEL_2);
}
void TIM2_Init(void)
{
	__HAL_RCC_TIM2_CLK_ENABLE();
	
	htim2.Instance = TIM2;
	htim2.Init.Prescaler = 8400-1;
	htim2.Init.Period = 500-1;
	htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
	htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
	if(HAL_TIM_Base_Init(&htim2) != HAL_OK)
	{
		Error_Handler();
	}
	__HAL_TIM_CLEAR_FLAG(&htim2,TIM_FLAG_UPDATE);
	HAL_NVIC_SetPriority(TIM2_IRQn,3,3);
	HAL_NVIC_EnableIRQ(TIM2_IRQn);
	HAL_TIM_Base_Start_IT(&htim2);
}
	
