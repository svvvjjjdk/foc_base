#ifndef _LCD_EX_H
#define _LCD_EX_H


void lcd_ex_st7789_reginit(void);
void lcd_ex_nt35310_reginit(void);
void lcd_ex_st7796_reginit(void);
void lcd_ex_nt35510_reginit(void);
void lcd_ex_ili9806_reginit(void);
void lcd_ex_ssd1963_reginit(void);
void lcd_ex_ili9341_reginit(void);

#endif
