#include "delay.h"
#include "main.h"
#include "../BSP/TIM/tim.h"

#if OS == 1
#define TIME_DELAY htim5
volatile int32_t flag_delay = 0;
//void delay_init(void)
//{
//	TIME_DELAY.Instance->PSC = 36-1;
//	TIME_DELAY.Instance->ARR = 2-1;		 //1us更新
//}
void delay_us(uint32_t i)
{
	flag_delay = i;
	HAL_TIM_Base_Start_IT(&TIME_DELAY);
	while(1)
	{
		if(flag_delay == 0)
		{
			break;
		}
		
	}
}
void  delay_ms(uint32_t i)
{
	for(uint8_t j = 0; j<i;j++)
	{
		delay_us(1000);
	}
}

void delay_s(uint32_t i)
{
	for(uint8_t j = 0; j<i;j++)
	{
		delay_ms(1000);
	}
}
#endif
#if OS == 0
/*用这里的函数会影响HAL_Get_Tick(),使时钟从零开始*/
/***************************
 * 作用：延时us级
 * 输入：整数i（1~798915）
 **************************/
 
void delay_us(uint32_t i)
{
    SysTick->LOAD = 9*i;
    SysTick->VAL = 0x00;
    SysTick->CTRL = 0x01;
    while(!(SysTick->CTRL&(0x01<<16)));
    SysTick->CTRL = 0x00;
    SysTick->VAL = 0x00;
}

/***************************
 * 作用：延时ms级
 * 输入：整数i（1~798）
 **************************/
void delay_ms(uint32_t i)
{
    SysTick->LOAD = 9000*i;
    SysTick->VAL = 0x00;
    SysTick->CTRL = 0x01;
    while(!(SysTick->CTRL&(0x01<<16)));
    SysTick->CTRL = 0x00;
    SysTick->VAL = 0x00;
}

/***************************
 * 作用：延时us级
 * 输入：整数i
 **************************/
void delay_s(uint32_t i)
{
    for(uint32_t j = 0 ;j<i*2;j++)
    delay_ms(500);
}
#endif
