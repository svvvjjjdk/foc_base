#ifndef __DELAY_H
#define __DELAY_H
#ifdef __cplusplus
extern "C"{
#endif
#include "main.h"

#define OS  1

void delay_s(uint32_t i);
void delay_ms(uint32_t i);
void delay_us(uint32_t i);
#if OS == 1
void delay_init(void);
extern volatile int32_t flag_delay ;
#endif
#ifdef __cplusplus
}
#endif
#endif
