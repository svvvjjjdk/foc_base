#include "../BSP/GPIO/gpio.h"

void Motor_Start_Gpio_Init(void);
void Key_Init(void);
void Hall_Sensor_R_Init(void);
void Zero_Pos_Init(void);

void GPOI_Init(void)
{
	Motor_Start_Gpio_Init();
	Key_Init();
	Hall_Sensor_R_Init();
	Zero_Pos_Init();
}

void Motor_Start_Gpio_Init(void)
{
	__HAL_RCC_GPIOF_CLK_ENABLE();
	
	HAL_GPIO_WritePin(GPIOF,GPIO_PIN_10,GPIO_PIN_SET);
	
	GPIO_InitTypeDef GPIO_InitTypeDefStructure = {0};
	GPIO_InitTypeDefStructure.Pin = GPIO_PIN_10;
	GPIO_InitTypeDefStructure.Mode= GPIO_MODE_OUTPUT_PP;
	GPIO_InitTypeDefStructure.Pull = GPIO_PULLUP;
	GPIO_InitTypeDefStructure.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOF,&GPIO_InitTypeDefStructure);
}

void Key_Init(void)
{
	__HAL_RCC_GPIOE_CLK_ENABLE();
	GPIO_InitTypeDef GPIO_InitTypeDefStructure = {0};
	GPIO_InitTypeDefStructure.Pin = GPIO_PIN_2;
	GPIO_InitTypeDefStructure.Mode= GPIO_MODE_IT_FALLING;
	GPIO_InitTypeDefStructure.Pull = GPIO_PULLUP;
	HAL_GPIO_Init(GPIOE,&GPIO_InitTypeDefStructure);
	HAL_NVIC_SetPriority(EXTI2_IRQn,2,0);
	HAL_NVIC_EnableIRQ(EXTI2_IRQn);
}

void Hall_Sensor_R_Init(void)
{
	__HAL_RCC_GPIOH_CLK_ENABLE();
	
	GPIO_InitTypeDef GPIO_InitTypeDefStructre={0};
	GPIO_InitTypeDefStructre.Pin = GPIO_PIN_10 | GPIO_PIN_11 | GPIO_PIN_12 ;
	GPIO_InitTypeDefStructre.Mode = GPIO_MODE_INPUT;
	GPIO_InitTypeDefStructre.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(GPIOH,&GPIO_InitTypeDefStructre);
}

void Zero_Pos_Init(void)
{
	__HAL_RCC_GPIOE_CLK_ENABLE();
	
	GPIO_InitTypeDef GPIO_InitTypeDefStructre={0};
	GPIO_InitTypeDefStructre.Pin = GPIO_PIN_6;
	GPIO_InitTypeDefStructre.Mode = GPIO_MODE_IT_RISING;
	GPIO_InitTypeDefStructre.Pull = GPIO_PULLDOWN;
	HAL_GPIO_Init(GPIOE,&GPIO_InitTypeDefStructre);
	HAL_NVIC_SetPriority(EXTI9_5_IRQn,1,0);
	HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);
}