#ifndef __GPIO_H
#define __GPIO_H
#ifdef __cplusplus
extern "C"{
#endif
#include "main.h"

void GPOI_Init(void);
void EXTI2_IRQHandler(void);
#ifdef __cplusplus
}
#endif
#endif

