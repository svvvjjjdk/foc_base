#include "../BSP/USART/usart.h"
#include <string.h>
#include <stdarg.h>
#include <stdio.h>


#ifdef USE_USART1

UART_HandleTypeDef huart1;
static void Usart1_Init(void)
{
	__HAL_RCC_USART1_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();
	
	GPIO_InitTypeDef GPIO_InitTypeDefStructureTx ={
		.Pin = USART1_TX_PIN ,
		.Mode = GPIO_MODE_AF_PP,
		.Pull = GPIO_NOPULL,
		.Speed = GPIO_SPEED_FREQ_VERY_HIGH,
		.Alternate = GPIO_AF7_USART1
	};
	HAL_GPIO_Init(USART1_GPIO_PORT, &GPIO_InitTypeDefStructureTx);
	
	huart1.Instance = USART1;
	huart1.Init.BaudRate = 115200;
	huart1.Init.WordLength = UART_WORDLENGTH_8B;
	huart1.Init.StopBits = UART_STOPBITS_1;
	huart1.Init.Parity = UART_PARITY_NONE;
	huart1.Init.Mode = UART_MODE_TX;
	huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart1.Init.OverSampling = UART_OVERSAMPLING_16;
	if(HAL_UART_Init(&huart1)!= HAL_OK)
	{
		Error_Handler();
	}
}

void uart_printf(const char* fmt,...)
{
	char buff[100];
	va_list args;
	va_start(args,fmt);
	vsnprintf(buff,sizeof(buff),fmt,args);
	va_end(args);
	HAL_UART_Transmit(&huart1,(uint8_t*)buff,strlen(buff),0xff);
}
#endif


void Usart_Init(void)
{
	Usart1_Init();
}




