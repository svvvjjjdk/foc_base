#ifndef __USART_H
#define __USART_H
#ifdef __cplusplus
extern "C"{
#endif
#include "main.h"
#define USE_USART1 
/*引脚定义*/
/*u1*/
#ifdef USE_USART1
#define USART1_TX_PIN GPIO_PIN_6
#define USART1_RX_PIN GPIO_PIN_7
#define USART1_GPIO_PORT GPIOB
#endif
	
	
void Usart_Init(void);
void uart_printf(const char* fmt,...);
#ifdef __cplusplus
}
#endif
#endif
