#include "main.h"
/*BSP*/
#include "../BSP/SYSTEM/sys.h" 
#include "../BSP/GPIO/gpio.h"
#include "../BSP/USART/usart.h"
#include "../BSP/TIM/tim.h"
#include "../BSP/ADC/adc.h"
/*SDK*/
#include "../SDK/foc_math/foc_math.h"
#include "lvgl.h"
#include "lv_port_disp_template.h"
#include "lv_port_indev_template.h"
#include "gui_guider.h"
#include "events_init.h"


FOC foc1(&htim1,&htim3);
int main(void)
{
	HAL_Init();
	RCC_SYSTEMSCLK_CONFIG();
	HAL_NVIC_SetPriorityGrouping(NVIC_PRIORITYGROUP_2);
	GPOI_Init();
	Usart_Init();
	TIM3_Init();
	TIM7_Init(); 
	TIM1_Init();
	TIM5_Init();
	TIM2_Init();
	Iabc_ADC_Init();
	lv_init();                         
  lv_port_disp_init();               
  lv_port_indev_init();
	setup_ui(&guider_ui);
  events_init(&guider_ui);
	while(1)
	{
		lv_meter_set_indicator_value(guider_ui.screen_speed_meter_speed,guider_ui.screen_speed_meter_speed_scale_0_ndline_0,(int32_t)foc1.Speed_Rpm);
		lv_label_set_text_fmt(guider_ui.screen_speed_label_1, "%d Rpm\n\n", (int32_t)foc1.Speed_Rpm);
		lv_task_handler();
		HAL_Delay(5);
	}
}


void Error_Handler(void)
{
	// 错误处理函数
	__disable_irq();
	while(1)
	{
	

	}
}
