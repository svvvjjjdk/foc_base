/*
* Copyright 2025 NXP
* NXP Proprietary. This software is owned or controlled by NXP and may only be used strictly in
* accordance with the applicable license terms. By expressly accepting such terms or by downloading, installing,
* activating and/or otherwise using the software, you are agreeing that you have read, and that you agree to
* comply with and are bound by, such license terms.  If you do not agree to be bound by the applicable license
* terms, then you may not retain, install, activate or otherwise use the software.
*/

#include "lvgl.h"
#include <stdio.h>
#include "gui_guider.h"
#include "events_init.h"
#include "widgets_init.h"



void setup_scr_screen_speed(lv_ui *ui)
{
    //Write codes screen_speed
    ui->screen_speed = lv_obj_create(NULL);
    lv_obj_set_size(ui->screen_speed, 800, 480);
    lv_obj_set_scrollbar_mode(ui->screen_speed, LV_SCROLLBAR_MODE_OFF);

    //Write style for screen_speed, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
    lv_obj_set_style_bg_opa(ui->screen_speed, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

    //Write codes screen_speed_cont_speed
    ui->screen_speed_cont_speed = lv_obj_create(ui->screen_speed);
    lv_obj_set_pos(ui->screen_speed_cont_speed, -1, 0);
    lv_obj_set_size(ui->screen_speed_cont_speed, 800, 480);
    lv_obj_set_scrollbar_mode(ui->screen_speed_cont_speed, LV_SCROLLBAR_MODE_OFF);

    //Write style for screen_speed_cont_speed, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
    lv_obj_set_style_border_width(ui->screen_speed_cont_speed, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_border_opa(ui->screen_speed_cont_speed, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_border_color(ui->screen_speed_cont_speed, lv_color_hex(0x2094f5), LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_border_side(ui->screen_speed_cont_speed, LV_BORDER_SIDE_FULL, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_radius(ui->screen_speed_cont_speed, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui->screen_speed_cont_speed, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_bg_color(ui->screen_speed_cont_speed, lv_color_hex(0x255a45), LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_bg_grad_dir(ui->screen_speed_cont_speed, LV_GRAD_DIR_NONE, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_top(ui->screen_speed_cont_speed, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_bottom(ui->screen_speed_cont_speed, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_left(ui->screen_speed_cont_speed, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_right(ui->screen_speed_cont_speed, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_shadow_width(ui->screen_speed_cont_speed, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

    //Write codes screen_speed_label_speed
    ui->screen_speed_label_speed = lv_label_create(ui->screen_speed_cont_speed);
    lv_label_set_text(ui->screen_speed_label_speed, "当前速度:\n\n");
    lv_label_set_long_mode(ui->screen_speed_label_speed, LV_LABEL_LONG_WRAP);
    lv_obj_set_pos(ui->screen_speed_label_speed, 136, 430);
    lv_obj_set_size(ui->screen_speed_label_speed, 101, 28);

    //Write style for screen_speed_label_speed, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
    lv_obj_set_style_border_width(ui->screen_speed_label_speed, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_radius(ui->screen_speed_label_speed, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_color(ui->screen_speed_label_speed, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(ui->screen_speed_label_speed, &lv_font_SourceHanSerifSC_Regular_21, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(ui->screen_speed_label_speed, 174, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_letter_space(ui->screen_speed_label_speed, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_line_space(ui->screen_speed_label_speed, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_align(ui->screen_speed_label_speed, LV_TEXT_ALIGN_LEFT, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui->screen_speed_label_speed, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_top(ui->screen_speed_label_speed, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_right(ui->screen_speed_label_speed, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_bottom(ui->screen_speed_label_speed, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_left(ui->screen_speed_label_speed, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_shadow_width(ui->screen_speed_label_speed, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

    //Write codes screen_speed_arc_speed
    ui->screen_speed_arc_speed = lv_arc_create(ui->screen_speed_cont_speed);
    lv_arc_set_mode(ui->screen_speed_arc_speed, LV_ARC_MODE_NORMAL);
    lv_arc_set_range(ui->screen_speed_arc_speed, -3000, 3000);
    lv_arc_set_bg_angles(ui->screen_speed_arc_speed, 110, 70);
    lv_arc_set_value(ui->screen_speed_arc_speed, 9);
    lv_arc_set_rotation(ui->screen_speed_arc_speed, 0);
    lv_obj_set_pos(ui->screen_speed_arc_speed, 508, 162);
    lv_obj_set_size(ui->screen_speed_arc_speed, 235, 232);

    //Write style for screen_speed_arc_speed, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
    lv_obj_set_style_bg_opa(ui->screen_speed_arc_speed, 197, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_bg_color(ui->screen_speed_arc_speed, lv_color_hex(0x1d1d24), LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_bg_grad_dir(ui->screen_speed_arc_speed, LV_GRAD_DIR_NONE, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_border_width(ui->screen_speed_arc_speed, 1, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_border_opa(ui->screen_speed_arc_speed, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_border_color(ui->screen_speed_arc_speed, lv_color_hex(0x1d1d24), LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_border_side(ui->screen_speed_arc_speed, LV_BORDER_SIDE_LEFT, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_arc_width(ui->screen_speed_arc_speed, 9, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_arc_opa(ui->screen_speed_arc_speed, 116, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_arc_color(ui->screen_speed_arc_speed, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_radius(ui->screen_speed_arc_speed, 75, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_top(ui->screen_speed_arc_speed, 10, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_bottom(ui->screen_speed_arc_speed, 10, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_left(ui->screen_speed_arc_speed, 10, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_right(ui->screen_speed_arc_speed, 10, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_shadow_width(ui->screen_speed_arc_speed, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

    //Write style for screen_speed_arc_speed, Part: LV_PART_INDICATOR, State: LV_STATE_DEFAULT.
    lv_obj_set_style_arc_width(ui->screen_speed_arc_speed, 12, LV_PART_INDICATOR|LV_STATE_DEFAULT);
    lv_obj_set_style_arc_opa(ui->screen_speed_arc_speed, 255, LV_PART_INDICATOR|LV_STATE_DEFAULT);
    lv_obj_set_style_arc_color(ui->screen_speed_arc_speed, lv_color_hex(0x2195f6), LV_PART_INDICATOR|LV_STATE_DEFAULT);

    //Write style for screen_speed_arc_speed, Part: LV_PART_KNOB, State: LV_STATE_DEFAULT.
    lv_obj_set_style_bg_opa(ui->screen_speed_arc_speed, 255, LV_PART_KNOB|LV_STATE_DEFAULT);
    lv_obj_set_style_bg_color(ui->screen_speed_arc_speed, lv_color_hex(0x2088df), LV_PART_KNOB|LV_STATE_DEFAULT);
    lv_obj_set_style_bg_grad_dir(ui->screen_speed_arc_speed, LV_GRAD_DIR_NONE, LV_PART_KNOB|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_all(ui->screen_speed_arc_speed, 3, LV_PART_KNOB|LV_STATE_DEFAULT);

    //Write codes screen_speed_label_speed_range
    ui->screen_speed_label_speed_range = lv_label_create(ui->screen_speed_cont_speed);
    lv_label_set_text(ui->screen_speed_label_speed_range, "调速范围 -3000~3000Rpm\n\n");
    lv_label_set_long_mode(ui->screen_speed_label_speed_range, LV_LABEL_LONG_WRAP);
    lv_obj_set_pos(ui->screen_speed_label_speed_range, 230, 8);
    lv_obj_set_size(ui->screen_speed_label_speed_range, 340, 27);

    //Write style for screen_speed_label_speed_range, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
    lv_obj_set_style_border_width(ui->screen_speed_label_speed_range, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_radius(ui->screen_speed_label_speed_range, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_color(ui->screen_speed_label_speed_range, lv_color_hex(0xdcdafd), LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(ui->screen_speed_label_speed_range, &lv_font_SourceHanSerifSC_Regular_21, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(ui->screen_speed_label_speed_range, 174, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_letter_space(ui->screen_speed_label_speed_range, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_line_space(ui->screen_speed_label_speed_range, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_align(ui->screen_speed_label_speed_range, LV_TEXT_ALIGN_CENTER, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui->screen_speed_label_speed_range, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_top(ui->screen_speed_label_speed_range, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_right(ui->screen_speed_label_speed_range, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_bottom(ui->screen_speed_label_speed_range, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_left(ui->screen_speed_label_speed_range, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_shadow_width(ui->screen_speed_label_speed_range, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

    //Write codes screen_speed_line_1
    ui->screen_speed_line_1 = lv_line_create(ui->screen_speed_cont_speed);
    static lv_point_t screen_speed_line_1[] = {{0, 0},{0, 90},};
    lv_line_set_points(ui->screen_speed_line_1, screen_speed_line_1, 2);
    lv_obj_set_pos(ui->screen_speed_line_1, 16, 1);
    lv_obj_set_size(ui->screen_speed_line_1, 1, 97);

    //Write style for screen_speed_line_1, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
    lv_obj_set_style_line_width(ui->screen_speed_line_1, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_line_color(ui->screen_speed_line_1, lv_color_hex(0x757575), LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_line_opa(ui->screen_speed_line_1, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_line_rounded(ui->screen_speed_line_1, true, LV_PART_MAIN|LV_STATE_DEFAULT);

    //Write codes screen_speed_line_2
    ui->screen_speed_line_2 = lv_line_create(ui->screen_speed_cont_speed);
    static lv_point_t screen_speed_line_2[] = {{0, 0},{0, 90},};
    lv_line_set_points(ui->screen_speed_line_2, screen_speed_line_2, 2);
    lv_obj_set_pos(ui->screen_speed_line_2, 83, 0);
    lv_obj_set_size(ui->screen_speed_line_2, 1, 97);

    //Write style for screen_speed_line_2, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
    lv_obj_set_style_line_width(ui->screen_speed_line_2, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_line_color(ui->screen_speed_line_2, lv_color_hex(0x757575), LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_line_opa(ui->screen_speed_line_2, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_line_rounded(ui->screen_speed_line_2, true, LV_PART_MAIN|LV_STATE_DEFAULT);

    //Write codes screen_speed_line_3
    ui->screen_speed_line_3 = lv_line_create(ui->screen_speed_cont_speed);
    static lv_point_t screen_speed_line_3[] = {{0, 0},{0, 90},};
    lv_line_set_points(ui->screen_speed_line_3, screen_speed_line_3, 2);
    lv_obj_set_pos(ui->screen_speed_line_3, 50, 0);
    lv_obj_set_size(ui->screen_speed_line_3, 5, 97);

    //Write style for screen_speed_line_3, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
    lv_obj_set_style_line_width(ui->screen_speed_line_3, 2, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_line_color(ui->screen_speed_line_3, lv_color_hex(0x757575), LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_line_opa(ui->screen_speed_line_3, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_line_rounded(ui->screen_speed_line_3, true, LV_PART_MAIN|LV_STATE_DEFAULT);

    //Write codes screen_speed_label_targes
    ui->screen_speed_label_targes = lv_label_create(ui->screen_speed_cont_speed);
    lv_label_set_text(ui->screen_speed_label_targes, "目标速度:\n\n");
    lv_label_set_long_mode(ui->screen_speed_label_targes, LV_LABEL_LONG_WRAP);
    lv_obj_set_pos(ui->screen_speed_label_targes, 516, 428);
    lv_obj_set_size(ui->screen_speed_label_targes, 96, 28);

    //Write style for screen_speed_label_targes, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
    lv_obj_set_style_border_width(ui->screen_speed_label_targes, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_radius(ui->screen_speed_label_targes, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_color(ui->screen_speed_label_targes, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(ui->screen_speed_label_targes, &lv_font_SourceHanSerifSC_Regular_21, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(ui->screen_speed_label_targes, 174, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_letter_space(ui->screen_speed_label_targes, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_line_space(ui->screen_speed_label_targes, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_align(ui->screen_speed_label_targes, LV_TEXT_ALIGN_LEFT, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui->screen_speed_label_targes, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_top(ui->screen_speed_label_targes, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_right(ui->screen_speed_label_targes, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_bottom(ui->screen_speed_label_targes, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_left(ui->screen_speed_label_targes, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_shadow_width(ui->screen_speed_label_targes, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

    //Write codes screen_speed_meter_speed
    ui->screen_speed_meter_speed = lv_meter_create(ui->screen_speed_cont_speed);
    // add scale ui->screen_speed_meter_speed_scale_0
    ui->screen_speed_meter_speed_scale_0 = lv_meter_add_scale(ui->screen_speed_meter_speed);
    lv_meter_set_scale_ticks(ui->screen_speed_meter_speed, ui->screen_speed_meter_speed_scale_0, 41, 2, 10, lv_color_hex(0xc9c5c5));
    lv_meter_set_scale_major_ticks(ui->screen_speed_meter_speed, ui->screen_speed_meter_speed_scale_0, 8, 5, 15, lv_color_hex(0xd8d87b), 20);
    lv_meter_set_scale_range(ui->screen_speed_meter_speed, ui->screen_speed_meter_speed_scale_0, -3000, 3000, 300, 120);

    // add needle line for ui->screen_speed_meter_speed_scale_0.
    ui->screen_speed_meter_speed_scale_0_ndline_0 = lv_meter_add_needle_line(ui->screen_speed_meter_speed, ui->screen_speed_meter_speed_scale_0, 5, lv_color_hex(0xde0808), -10);
    lv_meter_set_indicator_value(ui->screen_speed_meter_speed, ui->screen_speed_meter_speed_scale_0_ndline_0, 0);
    lv_obj_set_pos(ui->screen_speed_meter_speed, 85, 63);
    lv_obj_set_size(ui->screen_speed_meter_speed, 342, 342);

    //Write style for screen_speed_meter_speed, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
    lv_obj_set_style_bg_opa(ui->screen_speed_meter_speed, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_bg_color(ui->screen_speed_meter_speed, lv_color_hex(0x1d1d24), LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_bg_grad_dir(ui->screen_speed_meter_speed, LV_GRAD_DIR_NONE, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_radius(ui->screen_speed_meter_speed, 333, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_border_width(ui->screen_speed_meter_speed, 10, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_border_opa(ui->screen_speed_meter_speed, 255, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_border_color(ui->screen_speed_meter_speed, lv_color_hex(0x305370), LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_border_side(ui->screen_speed_meter_speed, LV_BORDER_SIDE_FULL, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_top(ui->screen_speed_meter_speed, 14, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_bottom(ui->screen_speed_meter_speed, 14, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_left(ui->screen_speed_meter_speed, 14, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_right(ui->screen_speed_meter_speed, 14, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_shadow_width(ui->screen_speed_meter_speed, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

    //Write style for screen_speed_meter_speed, Part: LV_PART_TICKS, State: LV_STATE_DEFAULT.
    lv_obj_set_style_text_color(ui->screen_speed_meter_speed, lv_color_hex(0xd8cdcd), LV_PART_TICKS|LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(ui->screen_speed_meter_speed, &lv_font_SourceHanSerifSC_Regular_21, LV_PART_TICKS|LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(ui->screen_speed_meter_speed, 255, LV_PART_TICKS|LV_STATE_DEFAULT);

    //Write style for screen_speed_meter_speed, Part: LV_PART_INDICATOR, State: LV_STATE_DEFAULT.
    lv_obj_set_style_bg_opa(ui->screen_speed_meter_speed, 255, LV_PART_INDICATOR|LV_STATE_DEFAULT);
    lv_obj_set_style_bg_color(ui->screen_speed_meter_speed, lv_color_hex(0x000000), LV_PART_INDICATOR|LV_STATE_DEFAULT);
    lv_obj_set_style_bg_grad_dir(ui->screen_speed_meter_speed, LV_GRAD_DIR_NONE, LV_PART_INDICATOR|LV_STATE_DEFAULT);

    //Write codes screen_speed_radiobtn_1
    ui->screen_speed_radiobtn_1 = lv_radiobtn_create(ui->screen_speed_cont_speed);
    ui->screen_speed_radiobtn_1_item0 =lv_radiobtn_add_item(ui->screen_speed_radiobtn_1, "start");
    ui->screen_speed_radiobtn_1_item1 =lv_radiobtn_add_item(ui->screen_speed_radiobtn_1, "stop");
		
    lv_obj_set_pos(ui->screen_speed_radiobtn_1, 648, 22);
    lv_obj_set_size(ui->screen_speed_radiobtn_1, 123, 111);

    //Write style state: LV_STATE_DEFAULT for &style_screen_speed_radiobtn_1_main_main_default
    static lv_style_t style_screen_speed_radiobtn_1_main_main_default;
    ui_init_style(&style_screen_speed_radiobtn_1_main_main_default);

    lv_style_set_pad_top(&style_screen_speed_radiobtn_1_main_main_default, 5);
    lv_style_set_pad_left(&style_screen_speed_radiobtn_1_main_main_default, 5);
    lv_style_set_pad_right(&style_screen_speed_radiobtn_1_main_main_default, 5);
    lv_style_set_pad_bottom(&style_screen_speed_radiobtn_1_main_main_default, 5);
    lv_style_set_border_width(&style_screen_speed_radiobtn_1_main_main_default, 7);
    lv_style_set_border_opa(&style_screen_speed_radiobtn_1_main_main_default, 255);
    lv_style_set_border_color(&style_screen_speed_radiobtn_1_main_main_default, lv_color_hex(0xe1d4d4));
    lv_style_set_border_side(&style_screen_speed_radiobtn_1_main_main_default, LV_BORDER_SIDE_FULL);
    lv_style_set_radius(&style_screen_speed_radiobtn_1_main_main_default, 6);
    lv_style_set_bg_opa(&style_screen_speed_radiobtn_1_main_main_default, 255);
    lv_style_set_bg_color(&style_screen_speed_radiobtn_1_main_main_default, lv_color_hex(0x1d1d24));
    lv_style_set_bg_grad_dir(&style_screen_speed_radiobtn_1_main_main_default, LV_GRAD_DIR_NONE);
    lv_style_set_shadow_width(&style_screen_speed_radiobtn_1_main_main_default, 0);
    lv_obj_add_style(ui->screen_speed_radiobtn_1, &style_screen_speed_radiobtn_1_main_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

    //Write style state: LV_STATE_DEFAULT for &style_screen_speed_radiobtn_1_extra_btns_main_default
    static lv_style_t style_screen_speed_radiobtn_1_extra_btns_main_default;
    ui_init_style(&style_screen_speed_radiobtn_1_extra_btns_main_default);

    lv_style_set_pad_top(&style_screen_speed_radiobtn_1_extra_btns_main_default, 13);
    lv_style_set_pad_right(&style_screen_speed_radiobtn_1_extra_btns_main_default, 0);
    lv_style_set_pad_bottom(&style_screen_speed_radiobtn_1_extra_btns_main_default, 0);
    lv_style_set_pad_left(&style_screen_speed_radiobtn_1_extra_btns_main_default, 0);
    lv_style_set_text_color(&style_screen_speed_radiobtn_1_extra_btns_main_default, lv_color_hex(0xffffff));
    lv_style_set_text_font(&style_screen_speed_radiobtn_1_extra_btns_main_default, &lv_font_SourceHanSerifSC_Regular_21);
    lv_style_set_text_opa(&style_screen_speed_radiobtn_1_extra_btns_main_default, 255);
    lv_style_set_text_letter_space(&style_screen_speed_radiobtn_1_extra_btns_main_default, 2);
    lv_style_set_radius(&style_screen_speed_radiobtn_1_extra_btns_main_default, 6);
    lv_style_set_bg_opa(&style_screen_speed_radiobtn_1_extra_btns_main_default, 0);
    lv_obj_add_style(ui->screen_speed_radiobtn_1_item1, &style_screen_speed_radiobtn_1_extra_btns_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_add_style(ui->screen_speed_radiobtn_1_item0, &style_screen_speed_radiobtn_1_extra_btns_main_default, LV_PART_MAIN|LV_STATE_DEFAULT);

    //Write style state: LV_STATE_DEFAULT for &style_screen_speed_radiobtn_1_extra_btns_indicator_default
    static lv_style_t style_screen_speed_radiobtn_1_extra_btns_indicator_default;
    ui_init_style(&style_screen_speed_radiobtn_1_extra_btns_indicator_default);

    lv_style_set_border_width(&style_screen_speed_radiobtn_1_extra_btns_indicator_default, 2);
    lv_style_set_border_opa(&style_screen_speed_radiobtn_1_extra_btns_indicator_default, 255);
    lv_style_set_border_color(&style_screen_speed_radiobtn_1_extra_btns_indicator_default, lv_color_hex(0x5cd624));
    lv_style_set_border_side(&style_screen_speed_radiobtn_1_extra_btns_indicator_default, LV_BORDER_SIDE_FULL);
    lv_style_set_radius(&style_screen_speed_radiobtn_1_extra_btns_indicator_default, 20);
    lv_style_set_bg_opa(&style_screen_speed_radiobtn_1_extra_btns_indicator_default, 255);
    lv_style_set_bg_color(&style_screen_speed_radiobtn_1_extra_btns_indicator_default, lv_color_hex(0xffffff));
    lv_style_set_bg_grad_dir(&style_screen_speed_radiobtn_1_extra_btns_indicator_default, LV_GRAD_DIR_NONE);
    lv_obj_add_style(ui->screen_speed_radiobtn_1_item1, &style_screen_speed_radiobtn_1_extra_btns_indicator_default, LV_PART_INDICATOR|LV_STATE_DEFAULT);
    lv_obj_add_style(ui->screen_speed_radiobtn_1_item0, &style_screen_speed_radiobtn_1_extra_btns_indicator_default, LV_PART_INDICATOR|LV_STATE_DEFAULT);

    //Write style state: LV_STATE_PRESSED for &style_screen_speed_radiobtn_1_extra_btns_indicator_pressed
    static lv_style_t style_screen_speed_radiobtn_1_extra_btns_indicator_pressed;
    ui_init_style(&style_screen_speed_radiobtn_1_extra_btns_indicator_pressed);

    lv_style_set_border_width(&style_screen_speed_radiobtn_1_extra_btns_indicator_pressed, 2);
    lv_style_set_border_opa(&style_screen_speed_radiobtn_1_extra_btns_indicator_pressed, 255);
    lv_style_set_border_color(&style_screen_speed_radiobtn_1_extra_btns_indicator_pressed, lv_color_hex(0x5cd624));
    lv_style_set_border_side(&style_screen_speed_radiobtn_1_extra_btns_indicator_pressed, LV_BORDER_SIDE_FULL);
    lv_style_set_radius(&style_screen_speed_radiobtn_1_extra_btns_indicator_pressed, 20);
    lv_style_set_bg_opa(&style_screen_speed_radiobtn_1_extra_btns_indicator_pressed, 255);
    lv_style_set_bg_color(&style_screen_speed_radiobtn_1_extra_btns_indicator_pressed, lv_color_hex(0xffffff));
    lv_style_set_bg_grad_dir(&style_screen_speed_radiobtn_1_extra_btns_indicator_pressed, LV_GRAD_DIR_NONE);
    lv_obj_add_style(ui->screen_speed_radiobtn_1_item1, &style_screen_speed_radiobtn_1_extra_btns_indicator_pressed, LV_PART_INDICATOR|LV_STATE_PRESSED);
    lv_obj_add_style(ui->screen_speed_radiobtn_1_item0, &style_screen_speed_radiobtn_1_extra_btns_indicator_pressed, LV_PART_INDICATOR|LV_STATE_PRESSED);

    //Write style state: LV_STATE_CHECKED for &style_screen_speed_radiobtn_1_extra_btns_indicator_checked
    static lv_style_t style_screen_speed_radiobtn_1_extra_btns_indicator_checked;
    ui_init_style(&style_screen_speed_radiobtn_1_extra_btns_indicator_checked);

    lv_style_set_border_width(&style_screen_speed_radiobtn_1_extra_btns_indicator_checked, 2);
    lv_style_set_border_opa(&style_screen_speed_radiobtn_1_extra_btns_indicator_checked, 255);
    lv_style_set_border_color(&style_screen_speed_radiobtn_1_extra_btns_indicator_checked, lv_color_hex(0x5cd624));
    lv_style_set_border_side(&style_screen_speed_radiobtn_1_extra_btns_indicator_checked, LV_BORDER_SIDE_FULL);
    lv_style_set_radius(&style_screen_speed_radiobtn_1_extra_btns_indicator_checked, 20);
    lv_style_set_bg_opa(&style_screen_speed_radiobtn_1_extra_btns_indicator_checked, 255);
    lv_style_set_bg_color(&style_screen_speed_radiobtn_1_extra_btns_indicator_checked, lv_color_hex(0xffffff));
    lv_style_set_bg_grad_dir(&style_screen_speed_radiobtn_1_extra_btns_indicator_checked, LV_GRAD_DIR_NONE);
    lv_obj_add_style(ui->screen_speed_radiobtn_1_item1, &style_screen_speed_radiobtn_1_extra_btns_indicator_checked, LV_PART_INDICATOR|LV_STATE_CHECKED);
    lv_obj_add_style(ui->screen_speed_radiobtn_1_item0, &style_screen_speed_radiobtn_1_extra_btns_indicator_checked, LV_PART_INDICATOR|LV_STATE_CHECKED);

    //Write style state: LV_STATE_CHECKED | LV_STATE_PRESSED for &style_screen_speed_radiobtn_1_extra_btns_indicator_checked_pressed
    static lv_style_t style_screen_speed_radiobtn_1_extra_btns_indicator_checked_pressed;
    ui_init_style(&style_screen_speed_radiobtn_1_extra_btns_indicator_checked_pressed);

    lv_style_set_border_width(&style_screen_speed_radiobtn_1_extra_btns_indicator_checked_pressed, 2);
    lv_style_set_border_opa(&style_screen_speed_radiobtn_1_extra_btns_indicator_checked_pressed, 255);
    lv_style_set_border_color(&style_screen_speed_radiobtn_1_extra_btns_indicator_checked_pressed, lv_color_hex(0x5cd624));
    lv_style_set_border_side(&style_screen_speed_radiobtn_1_extra_btns_indicator_checked_pressed, LV_BORDER_SIDE_FULL);
    lv_style_set_radius(&style_screen_speed_radiobtn_1_extra_btns_indicator_checked_pressed, 20);
    lv_style_set_bg_opa(&style_screen_speed_radiobtn_1_extra_btns_indicator_checked_pressed, 255);
    lv_style_set_bg_color(&style_screen_speed_radiobtn_1_extra_btns_indicator_checked_pressed, lv_color_hex(0xffffff));
    lv_style_set_bg_grad_dir(&style_screen_speed_radiobtn_1_extra_btns_indicator_checked_pressed, LV_GRAD_DIR_NONE);
    lv_obj_add_style(ui->screen_speed_radiobtn_1_item1, &style_screen_speed_radiobtn_1_extra_btns_indicator_checked_pressed, LV_PART_INDICATOR|LV_STATE_CHECKED | LV_STATE_PRESSED);
    lv_obj_add_style(ui->screen_speed_radiobtn_1_item0, &style_screen_speed_radiobtn_1_extra_btns_indicator_checked_pressed, LV_PART_INDICATOR|LV_STATE_CHECKED | LV_STATE_PRESSED);

    //Write style state: LV_STATE_DEFAULT for &style_screen_speed_radiobtn_1_extra_btns_custom_default
    static lv_style_t style_screen_speed_radiobtn_1_extra_btns_custom_default;
    ui_init_style(&style_screen_speed_radiobtn_1_extra_btns_custom_default);

    lv_style_set_border_width(&style_screen_speed_radiobtn_1_extra_btns_custom_default, 2);
    lv_style_set_border_opa(&style_screen_speed_radiobtn_1_extra_btns_custom_default, 0);
    lv_style_set_border_color(&style_screen_speed_radiobtn_1_extra_btns_custom_default, lv_color_hex(0xffffff));
    lv_style_set_border_side(&style_screen_speed_radiobtn_1_extra_btns_custom_default, LV_BORDER_SIDE_FULL);
    lv_style_set_radius(&style_screen_speed_radiobtn_1_extra_btns_custom_default, 20);
    lv_style_set_bg_opa(&style_screen_speed_radiobtn_1_extra_btns_custom_default, 0);
    lv_obj_add_style(ui->screen_speed_radiobtn_1_item1, &style_screen_speed_radiobtn_1_extra_btns_custom_default, LV_PART_CUSTOM_FIRST|LV_STATE_DEFAULT);
    lv_obj_add_style(ui->screen_speed_radiobtn_1_item0, &style_screen_speed_radiobtn_1_extra_btns_custom_default, LV_PART_CUSTOM_FIRST|LV_STATE_DEFAULT);

    //Write style state: LV_STATE_PRESSED for &style_screen_speed_radiobtn_1_extra_btns_custom_pressed
    static lv_style_t style_screen_speed_radiobtn_1_extra_btns_custom_pressed;
    ui_init_style(&style_screen_speed_radiobtn_1_extra_btns_custom_pressed);

    lv_style_set_border_width(&style_screen_speed_radiobtn_1_extra_btns_custom_pressed, 2);
    lv_style_set_border_opa(&style_screen_speed_radiobtn_1_extra_btns_custom_pressed, 0);
    lv_style_set_border_color(&style_screen_speed_radiobtn_1_extra_btns_custom_pressed, lv_color_hex(0xffffff));
    lv_style_set_border_side(&style_screen_speed_radiobtn_1_extra_btns_custom_pressed, LV_BORDER_SIDE_FULL);
    lv_style_set_radius(&style_screen_speed_radiobtn_1_extra_btns_custom_pressed, 20);
    lv_style_set_bg_opa(&style_screen_speed_radiobtn_1_extra_btns_custom_pressed, 0);
    lv_obj_add_style(ui->screen_speed_radiobtn_1_item1, &style_screen_speed_radiobtn_1_extra_btns_custom_pressed, LV_PART_CUSTOM_FIRST|LV_STATE_PRESSED);
    lv_obj_add_style(ui->screen_speed_radiobtn_1_item0, &style_screen_speed_radiobtn_1_extra_btns_custom_pressed, LV_PART_CUSTOM_FIRST|LV_STATE_PRESSED);

    //Write style state: LV_STATE_CHECKED for &style_screen_speed_radiobtn_1_extra_btns_custom_checked
    static lv_style_t style_screen_speed_radiobtn_1_extra_btns_custom_checked;
    ui_init_style(&style_screen_speed_radiobtn_1_extra_btns_custom_checked);

    lv_style_set_border_width(&style_screen_speed_radiobtn_1_extra_btns_custom_checked, 2);
    lv_style_set_border_opa(&style_screen_speed_radiobtn_1_extra_btns_custom_checked, 255);
    lv_style_set_border_color(&style_screen_speed_radiobtn_1_extra_btns_custom_checked, lv_color_hex(0x5cd624));
    lv_style_set_border_side(&style_screen_speed_radiobtn_1_extra_btns_custom_checked, LV_BORDER_SIDE_FULL);
    lv_style_set_radius(&style_screen_speed_radiobtn_1_extra_btns_custom_checked, 20);
    lv_style_set_bg_opa(&style_screen_speed_radiobtn_1_extra_btns_custom_checked, 255);
    lv_style_set_bg_color(&style_screen_speed_radiobtn_1_extra_btns_custom_checked, lv_color_hex(0x5cd624));
    lv_style_set_bg_grad_dir(&style_screen_speed_radiobtn_1_extra_btns_custom_checked, LV_GRAD_DIR_NONE);
    lv_obj_add_style(ui->screen_speed_radiobtn_1_item1, &style_screen_speed_radiobtn_1_extra_btns_custom_checked, LV_PART_CUSTOM_FIRST|LV_STATE_CHECKED);
    lv_obj_add_style(ui->screen_speed_radiobtn_1_item0, &style_screen_speed_radiobtn_1_extra_btns_custom_checked, LV_PART_CUSTOM_FIRST|LV_STATE_CHECKED);

    //Write style state: LV_STATE_CHECKED | LV_STATE_PRESSED for &style_screen_speed_radiobtn_1_extra_btns_custom_checked_pressed
    static lv_style_t style_screen_speed_radiobtn_1_extra_btns_custom_checked_pressed;
    ui_init_style(&style_screen_speed_radiobtn_1_extra_btns_custom_checked_pressed);

    lv_style_set_border_width(&style_screen_speed_radiobtn_1_extra_btns_custom_checked_pressed, 2);
    lv_style_set_border_opa(&style_screen_speed_radiobtn_1_extra_btns_custom_checked_pressed, 255);
    lv_style_set_border_color(&style_screen_speed_radiobtn_1_extra_btns_custom_checked_pressed, lv_color_hex(0x5cd624));
    lv_style_set_border_side(&style_screen_speed_radiobtn_1_extra_btns_custom_checked_pressed, LV_BORDER_SIDE_FULL);
    lv_style_set_radius(&style_screen_speed_radiobtn_1_extra_btns_custom_checked_pressed, 20);
    lv_style_set_bg_opa(&style_screen_speed_radiobtn_1_extra_btns_custom_checked_pressed, 255);
    lv_style_set_bg_color(&style_screen_speed_radiobtn_1_extra_btns_custom_checked_pressed, lv_color_hex(0x5cd624));
    lv_style_set_bg_grad_dir(&style_screen_speed_radiobtn_1_extra_btns_custom_checked_pressed, LV_GRAD_DIR_NONE);
    lv_obj_add_style(ui->screen_speed_radiobtn_1_item1, &style_screen_speed_radiobtn_1_extra_btns_custom_checked_pressed, LV_PART_CUSTOM_FIRST|LV_STATE_CHECKED | LV_STATE_PRESSED);
    lv_obj_add_style(ui->screen_speed_radiobtn_1_item0, &style_screen_speed_radiobtn_1_extra_btns_custom_checked_pressed, LV_PART_CUSTOM_FIRST|LV_STATE_CHECKED | LV_STATE_PRESSED);
		lv_obj_add_state(ui->screen_speed_radiobtn_1_item1, LV_STATE_CHECKED);

    //Write codes screen_speed_label_1
    ui->screen_speed_label_1 = lv_label_create(ui->screen_speed_cont_speed);
    lv_label_set_text(ui->screen_speed_label_1, "-1000 Rpm\n\n");
    lv_label_set_long_mode(ui->screen_speed_label_1, LV_LABEL_LONG_WRAP);
    lv_obj_set_pos(ui->screen_speed_label_1, 248, 430);
    lv_obj_set_size(ui->screen_speed_label_1, 110, 28);

    //Write style for screen_speed_label_1, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
    lv_obj_set_style_border_width(ui->screen_speed_label_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_radius(ui->screen_speed_label_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_color(ui->screen_speed_label_1, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(ui->screen_speed_label_1, &lv_font_SourceHanSerifSC_Regular_21, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(ui->screen_speed_label_1, 174, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_letter_space(ui->screen_speed_label_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_line_space(ui->screen_speed_label_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_align(ui->screen_speed_label_1, LV_TEXT_ALIGN_LEFT, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui->screen_speed_label_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_top(ui->screen_speed_label_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_right(ui->screen_speed_label_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_bottom(ui->screen_speed_label_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_left(ui->screen_speed_label_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_shadow_width(ui->screen_speed_label_1, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

    //Write codes screen_speed_label_2
    ui->screen_speed_label_2 = lv_label_create(ui->screen_speed_cont_speed);
    lv_label_set_text(ui->screen_speed_label_2, "-1000 Rpm\n\n");
    lv_label_set_long_mode(ui->screen_speed_label_2, LV_LABEL_LONG_WRAP);
    lv_obj_set_pos(ui->screen_speed_label_2, 623, 428);
    lv_obj_set_size(ui->screen_speed_label_2, 114, 28);

    //Write style for screen_speed_label_2, Part: LV_PART_MAIN, State: LV_STATE_DEFAULT.
    lv_obj_set_style_border_width(ui->screen_speed_label_2, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_radius(ui->screen_speed_label_2, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_color(ui->screen_speed_label_2, lv_color_hex(0x000000), LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_font(ui->screen_speed_label_2, &lv_font_SourceHanSerifSC_Regular_21, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_opa(ui->screen_speed_label_2, 174, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_letter_space(ui->screen_speed_label_2, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_line_space(ui->screen_speed_label_2, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_text_align(ui->screen_speed_label_2, LV_TEXT_ALIGN_LEFT, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_bg_opa(ui->screen_speed_label_2, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_top(ui->screen_speed_label_2, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_right(ui->screen_speed_label_2, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_bottom(ui->screen_speed_label_2, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_pad_left(ui->screen_speed_label_2, 0, LV_PART_MAIN|LV_STATE_DEFAULT);
    lv_obj_set_style_shadow_width(ui->screen_speed_label_2, 0, LV_PART_MAIN|LV_STATE_DEFAULT);

    //The custom code of screen_speed.


    //Update current screen layout.
    lv_obj_update_layout(ui->screen_speed);

    //Init events for screen.
    events_init_screen_speed(ui);
}
