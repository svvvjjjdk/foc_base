/*
* Copyright 2025 NXP
* NXP Proprietary. This software is owned or controlled by NXP and may only be used strictly in
* accordance with the applicable license terms. By expressly accepting such terms or by downloading, installing,
* activating and/or otherwise using the software, you are agreeing that you have read, and that you agree to
* comply with and are bound by, such license terms.  If you do not agree to be bound by the applicable license
* terms, then you may not retain, install, activate or otherwise use the software.
*/

#include "events_init.h"
#include <stdio.h>
#include "lvgl.h"
#include "../SDK/foc_math/foc_math.h"
#include "../BSP/TIM/tim.h"
#if LV_USE_GUIDER_SIMULATOR && LV_USE_FREEMASTER
#include "freemaster_client.h"
#endif
extern FOC foc1;
static void screen_speed_arc_speed_event_handler (lv_event_t *e)
{
    lv_event_code_t code = lv_event_get_code(e);
    switch (code) {
    case LV_EVENT_PRESSING:
    {
			  int16_t s = lv_arc_get_value(guider_ui.screen_speed_arc_speed);
        lv_label_set_text_fmt(guider_ui.screen_speed_label_2, "%d Rpm\n\n", s);
				foc1.speed_targe = (float)s;
        break;
    }
    default:
        break;
    }
}

static void screen_speed_radiobtn_1_item0_event_handler (lv_event_t *e)
{
		static uint8_t i = 0;
    lv_event_code_t code = lv_event_get_code(e);
    switch (code) {
    case LV_EVENT_SHORT_CLICKED:
    {
			if(!i)
			{
				i = 1;
				lv_obj_clear_state(guider_ui.screen_speed_radiobtn_1_item1, LV_STATE_CHECKED);
			}
			if(foc1.motor_state == STOP)
			{
				/*��λ������*/
				lv_arc_set_value(guider_ui.screen_speed_arc_speed,0);
				lv_label_set_text(guider_ui.screen_speed_label_2, "0 Rpm\n\n");
				/*��λ����*/
				lv_meter_set_indicator_value(guider_ui.screen_speed_meter_speed,guider_ui.screen_speed_meter_speed_scale_0_ndline_0,0);
				foc1.speed_targe = 0.0;
				HAL_TIM_Base_Start(&htim7);
				foc1.motor_state = RUN;
			}
        break;
    }
    default:
        break;
    }
}

static void screen_speed_radiobtn_1_item1_event_handler (lv_event_t *e)
{
    lv_event_code_t code = lv_event_get_code(e);
    switch (code) {
    case LV_EVENT_SHORT_CLICKED:
    {
			if(foc1.motor_state == RUN)
			{
				foc1.speed_targe = 0.0;
				while(!(foc1.Speed_Rpm < 0.5f&&foc1.Speed_Rpm > -0.5f));
				HAL_Delay(100);
				while(!(foc1.Speed_Rpm < 0.5f&&foc1.Speed_Rpm > -0.5f));
				HAL_TIM_Base_Stop(&htim7);
				foc1.motor_state = STOP;
			}
        break;
    }
    default:
        break;
    }
}

void events_init_screen_speed (lv_ui *ui)
{
    lv_obj_add_event_cb(ui->screen_speed_arc_speed, screen_speed_arc_speed_event_handler, LV_EVENT_ALL, ui);
    lv_obj_add_event_cb(ui->screen_speed_radiobtn_1_item0, screen_speed_radiobtn_1_item0_event_handler, LV_EVENT_ALL, ui);
    lv_obj_add_event_cb(ui->screen_speed_radiobtn_1_item1, screen_speed_radiobtn_1_item1_event_handler, LV_EVENT_ALL, ui);
}


void events_init(lv_ui *ui)
{

}
