#ifndef __PID_H
#define __PID_H
#ifdef __cplusplus
extern "C"{
#endif
#include "main.h"
typedef struct
{
    //PID运算模式
    uint8_t mode;
    //PID 三个基本参数
    float Kp;
    float Ki;
    float Kd;

    float max_out;  //PID最大输出
    float max_iout; //PID最大积分输出

    float set;	  //PID目标值
    float fdb;	  //PID当前值

    float out;		//三项叠加输出
    float Pout;		//比例项输出
    float Iout;		//积分项输出
    float Dout;		//微分项输出
    //微分项最近三个值 0最新 1上一次 2上上次
    float Dbuf[3];  
    //误差项最近三个值 0最新 1上一次 2上上次
    float error[3];  

} pid_type_def;

enum PID_MODE
{
    PID_POSITION = 0,      //位置式
    PID_DELTA              //增量式
};

#define LimitMax(input, max)   \
    {                          \
        if (input > max)       \
        {                      \
            input = max;       \
        }                      \
        else if (input < -max) \
        {                      \
            input = -max;      \
        }                      \
    }


float PID_calc(pid_type_def *pid, float ref, float set);  //结构体， 当前值 目标值
void PID_clear(pid_type_def *pid);                  
void PID_Init(pid_type_def *pid, uint8_t mode, const float PID[3], float max_out, float max_iout); //结构体，运算模式，【Kp ki kd】，输出限幅，积分限幅
#ifdef __cplusplus
}
#endif
#endif
