#include "../SDK/foc_math/foc_math.h"
#include "arm_math.h"
#include <array>
#include <algorithm>
#include <numeric>
/*������*/
const float Sqart_Three = 1.7320508075688772;
/*PI*/
const float pi = 3.1415926;
/*ARR*/
const float pwm_period = 4199.0f;

const float pid_param_speed_high_speed[3] = {0.00204,0.0003,0.002};
const float pid_param_i_high_speed[3] = {0.0888,0.0637,0};

const float pid_param_speed_low_speed[3] = {0.00503,0.00005,0};
const float pid_param_i_low_speed[3] = {0.060799,0.003699,0};
/**
* \brief FOC   ���캯��
 * \param[out] 
 * \param[in]
 * \param[in]
 * \return 
 *      \arg 
 *      \arg 
*/
FOC::FOC(TIM_HandleTypeDef *htim,TIM_HandleTypeDef *htim1):htim_swpu(htim),htim_encoder(htim1)
{
//	float a = 2.0f*pi/Ls*Rs*1000.f;
//  float pid_param_i[3] = {a*Ls*0.001f,a*Rs,0};
	
	PID_Init(&PID_Id,PID_POSITION,pid_param_i_low_speed,VMAX,VMAX);
	PID_Init(&PID_Iq,PID_POSITION,pid_param_i_low_speed,VMAX,VMAX);
	PID_Init(&PID_Speed,PID_POSITION,pid_param_speed_low_speed,4,2);
  
}

/**
* \brief Clark_step   clark�任
 * \param[out] 
 * \param[in]
 * \param[in]
 * \return 
 *      \arg 
 *      \arg 
*/
void FOC::Clark_step( void)
{
	 A_B_C_T iabc = {Iabc.A,Iabc.B,Iabc.C};
	 
   I_Alpha_Beta.Alpha = (iabc.A - (iabc.B + iabc.C) * 0.5f) * 2.0f /
    3.0;

  I_Alpha_Beta.Beta = (iabc.B - iabc.C) * 0.66666666666666663f *
    Sqart_Three / 2.0f;
}

/**
* \brief inv_Clark_step  clark���任
 * \param[out] 
 * \param[in]
 * \param[in]
 * \return 
 *      \arg 
 *      \arg 
*/
void FOC::inv_Clark_step(Alpha_Beta_T *inv_Clark_U, A_B_C_T *inv_Clark_Y)
{
  float B_tmp;

  inv_Clark_Y->A = inv_Clark_U->Alpha;

  B_tmp = inv_Clark_U->Alpha * -0.5;


  inv_Clark_Y->B = inv_Clark_U->Beta * Sqart_Three / 2.0 + B_tmp;


  inv_Clark_Y->C = B_tmp - 0.8660254037844386 * inv_Clark_U->Beta;
}
/**
* \brief Park_step park�任
 * \param[out] 
 * \param[in]
 * \param[in]
 * \return 
 *      \arg 
 *      \arg 
*/
void FOC::Park_step(void)
{
  float D_tmp;
  float D_tmp_0;
	float angle = Angle;
	Alpha_Beta_T i_alpha_beta = {I_Alpha_Beta.Alpha,I_Alpha_Beta.Beta};

  D_tmp = arm_sin_f32(angle);
  D_tmp_0 = arm_cos_f32(angle);

  Idq.D = D_tmp_0 * i_alpha_beta.Alpha + D_tmp * i_alpha_beta.Beta;
	
  Idq.Q = -D_tmp * i_alpha_beta.Alpha + D_tmp_0 * i_alpha_beta.Beta;
}
/**
* \brief Inv_Park_step park���任
 * \param[in] 
 * \return 
 *      \arg 
 *      \arg 
*/
void FOC::Inv_Park_step(D_Q_T *Inv_Park_U)
{
		float angle = Angle;
//		while(angle > 2*pi) angle -= 2*pi;
//		while(angle < 0)    angle += 2*pi;
    float s = arm_sin_f32(angle);
    float c = arm_cos_f32(angle);
    Re_U_Alpha_Beta.Alpha = c * Inv_Park_U->D - s * Inv_Park_U->Q;
    Re_U_Alpha_Beta.Beta  = s * Inv_Park_U->D + c * Inv_Park_U->Q;
}


/**
* \brief feedback_road ������·
 * \param[in] 
 * \return 
 *      \arg 
 *      \arg 
*/
void FOC::I_feedback_road(D_Q_T idq,D_Q_T &udq)
{
//	const float flux_const = B_EMF/PN/104.72f;  //��������  V/(krpm)->V/(rad/s), 104.72f->pi/30*1000
//	const float We = Wm*PN ;						// ����ٶ�
	Clark_step();
	Park_step();
//	udq.D = PID_calc(&(PID_Id),Idq.D,idq.D)-We*Ls*Idq.Q;
//	udq.Q = PID_calc(&(PID_Iq),Idq.Q,idq.Q)+ (We*(flux_const+Ls*Idq.D));
	
  float v_d, v_q;
	v_d = PID_calc(&(PID_Id),Idq.D,idq.D);
	v_q = PID_calc(&(PID_Iq),Idq.Q,idq.Q);
	float v_mag = sqrtf(v_d * v_d + v_q * v_q);
	if (v_mag > VMAX) {
			float scale = VMAX / v_mag;
			v_d *= scale;
			v_q *= scale;
	}
	udq.D = v_d;
	udq.Q = v_q;

}

void FOC::Speed_feedback_road(float targetSpeed, D_Q_T &idq)
{
    static uint8_t sample_index = 0;
    static std::array<int32_t, 10> speed_buffer{};
    static int64_t last_pos = 0;
		float alpha;
		
    // ��ǰ���λ��
    int64_t now_pos = static_cast<int64_t>(encoder_cnt) * 4000 + htim_encoder->Instance->CNT;
    int32_t delta = now_pos - last_pos;
    last_pos = now_pos;

    // ���������������32 λ��������
    if(delta > 2147483647) delta -= 4294967296;
    if(delta < -2147483647) delta += 4294967296;
			
    // �жϸ��������
    bool high_speed = (abs(Speed_Rpm) > 600);
   
    float speed_rpm_now;
		
     // ���뻺����
		speed_buffer[sample_index++] = delta;

		if(sample_index >= speed_buffer.size())
		{
			sample_index = 0;
			auto temp = speed_buffer;
			if(high_speed)
			{
				
				PID_Id.Kp = PID_Iq.Kp = pid_param_i_high_speed[0];
				PID_Id.Ki = PID_Iq.Ki = pid_param_i_high_speed[1];
				PID_Id.Kd = PID_Iq.Kd = pid_param_i_high_speed[2];
				PID_Speed.Kp = pid_param_speed_high_speed[0];
				PID_Speed.Ki = pid_param_speed_high_speed[1];
				PID_Speed.Kd = pid_param_speed_high_speed[2];
				// ȥ�������Сֵ��ƽ��
				std::sort(temp.begin(), temp.end());
				int32_t sum = std::accumulate(temp.begin() + 1, temp.end() - 1, 0);
				float avg_pulse = float(sum) / (temp.size() - 2);
				// ת��Ϊ rpm
				speed_rpm_now = avg_pulse * 60.0f / 4000.0f * 5000;
				alpha = 0.3f;
				
			}
			else
			{
				PID_Id.Kp = PID_Iq.Kp = pid_param_i_low_speed[0];
				PID_Id.Ki = PID_Iq.Ki = pid_param_i_low_speed[1];
				PID_Id.Kd = PID_Iq.Kd = pid_param_i_low_speed[2];
				PID_Speed.Kp = pid_param_speed_low_speed[0];
				PID_Speed.Ki = pid_param_speed_low_speed[1];
				PID_Speed.Kd = pid_param_speed_low_speed[2];
				int32_t sum = std::accumulate(temp.begin(), temp.end(), 0);
				float avg_pulse = float(sum) / temp.size();
				// ת��Ϊ rpm
				speed_rpm_now = avg_pulse * 60.0f * 5000/ 4000.0f ;
				alpha = 0.1f;
			  
			}
				// һ�׵�ͨ�˲�
				Speed_Rpm = Speed_Rpm * (1.0f - alpha) + speed_rpm_now * alpha;
				// �ٶ�С����ֵ����
				if(std::abs(Speed_Rpm) < 0.5f) Speed_Rpm = 0;
				// PID ����
				float old_iq = idq.Q;
				idq.Q = PID_calc(&PID_Speed, Speed_Rpm, targetSpeed);
				// ��������
				float step_limit = 2;
				float delta_iq = idq.Q - old_iq;
				if(delta_iq > step_limit) idq.Q = old_iq + step_limit;
				else if(delta_iq < -step_limit) idq.Q = old_iq - step_limit;
	  }
}



/**
* \brief openloop_road ������·
 * \param[in] 
 * \return 
 *      \arg 
 *      \arg 
*/
void FOC::openloop_road(D_Q_T *udq)
{
	Inv_Park_step(udq);
	Svpwm();
}

/**
* \brief Svpwm �ռ�ʸ������
 * \param[in] 
 * \return 
 *      \arg 
 *      \arg 
*/
void FOC::Svpwm(void)
{
			/*ϵ��*/
		const float K =  Sqart_Three/VDC;
    //  Clarke ����
    float alpha = Re_U_Alpha_Beta.Alpha;
    float beta  = Re_U_Alpha_Beta.Beta;

    // ���������ο���ѹͶӰ
    float Vref1 = beta;
    float Vref2 = 0.5f * (Sqart_Three * alpha - beta);
    float Vref3 = -0.5f * (Sqart_Three * alpha + beta);

    // �����жϣ�����Ϊ N��
    uint8_t A = (Vref1 > 0) ? 1 : 0;
    uint8_t B = (Vref2 > 0) ? 1 : 0;
    uint8_t C = (Vref3 > 0) ? 1 : 0;
    uint8_t N = 4 * C + 2 * B + A;
    if (N == 0) N = 1; // ������Ч����

    // ����������
    struct SectorInfo {
        int8_t s1, s2;
        const float* v1;
        const float* v2;
    };

    const SectorInfo sector_table[7] = {
				{ 0,  0, nullptr,     nullptr     },  // N=0
				{ -1, -1, &Vref2,     &Vref3      },  // N=1 -> Sector 2
				{ -1, -1, &Vref3,     &Vref1      },  // N=2 -> Sector 6
				{ +1, +1, &Vref2,     &Vref1      },  // N=3 -> Sector 1
				{ -1, -1, &Vref1,     &Vref2      },  // N=4 -> Sector 4
				{ +1, +1, &Vref1,     &Vref3      },  // N=5 -> Sector 3
				{ +1, +1, &Vref3,     &Vref2      },  // N=6 -> Sector 5
		};


    // ���� T1 T2
    float T1 = K * sector_table[N].s1 * (*sector_table[N].v1);
    float T2 = K * sector_table[N].s2 * (*sector_table[N].v2);

    // ��һ��
    float Tsum = T1 + T2;
    if (Tsum > 1.0f) {
        T1 = T1 / Tsum;
        T2 = 1.0f - T1;
    }
		
    // ���ĶԳ�����������
		float Ta = (1-T1-T2)/2.0f;
		float Tb = Ta + T1;
		float Tc = Tb + T2;

    // ������ PWM ����
    uint16_t ta_i = (uint16_t)(Ta * pwm_period);
    uint16_t tb_i = (uint16_t)(Tb * pwm_period);
    uint16_t tc_i = (uint16_t)(Tc * pwm_period);

    // ͨ��ӳ�䣺sector -> (U, V, W)
    const uint8_t cmp_map[7][3] = {
        {0, 0, 0},        // N = 0 ��Ч
        {2, 1, 3},        // N = 1
        {1, 3, 2},        // N = 2
        {1, 2, 3},        // N = 3
        {3, 2, 1},        // N = 4
        {3, 1, 2},        // N = 5
        {2, 3, 1},        // N = 6
    };

    const uint8_t* map = cmp_map[N];
    uint16_t cmp[3] = { ta_i, tb_i, tc_i };
		ta_i = ta_i>3612 ? 3612 : ta_i;
		tb_i = tb_i>3612 ? 3612 : tb_i;
		tc_i = tc_i>3612 ? 3612 : tc_i;
    __HAL_TIM_SetCompare(htim_swpu, TIM_CHANNEL_1, cmp[map[0] - 1]);
    __HAL_TIM_SetCompare(htim_swpu, TIM_CHANNEL_2, cmp[map[1] - 1]);
    __HAL_TIM_SetCompare(htim_swpu, TIM_CHANNEL_3, cmp[map[2] - 1]);
}

/**
* \brief Get_angle  ��ȡ���ڽǶ�
 * \param[in] 
 * \return 
 *      \arg 
 *      \arg 
*/
float FOC::Get_angle(void)
{
	/*��������ĶԼ���д,1000�߱�����*/
	/*��е�Ƕ�0~90����Ƕȵ�һ�� 0~360*4*/
	// 4000��������Ӧ4����Ƕ�����
   // ��е�Ƕ� [0, 2��)
    float mech_angle = ((int)(htim_encoder->Instance->CNT)/ 4000.0f) * 2.0f * pi;

    // ��Ƕ� = ��е�Ƕ� �� ������
    float elec_angle = mech_angle * PN;

    // ��һ���� [0, 2��)
    elec_angle = fmodf(elec_angle, 2*pi);

    return elec_angle;
}

void FOC::Find_Zero(void)
{
	const uint16_t hall_vctor_uvw[6][3]={
		{0,0,419},{0,419,0},{0,419,419},{419,0,0},{419,0,419},{419,419,0}
	};
	 uint8_t h1 = HAL_GPIO_ReadPin(GPIOH, GPIO_PIN_10);
   uint8_t h2 = HAL_GPIO_ReadPin(GPIOH, GPIO_PIN_11);
   uint8_t h3 = HAL_GPIO_ReadPin(GPIOH, GPIO_PIN_12);

    uint8_t hall_code = (h1 << 2) | (h2 << 1) | h3;
		if(hall_code == 0)
		{
			;
		}
		else
		{
			__HAL_TIM_SetCompare(htim_swpu,TIM_CHANNEL_1,hall_vctor_uvw[hall_code-1][0]);
			__HAL_TIM_SetCompare(htim_swpu,TIM_CHANNEL_2,hall_vctor_uvw[hall_code-1][1]);
			__HAL_TIM_SetCompare(htim_swpu,TIM_CHANNEL_3,hall_vctor_uvw[hall_code-1][2]);
		}
		
}

/**
* \brief Get_Wm  ��ȡ���ڻ�е���ٶ�
 * \param[in] 
 * \return 
 *      \arg 
 *      \arg 
*/
void FOC::Get_Wm(int Fre)
{
	static int re_count;										//����������ֵ
	static float old_Wm = 0.0f;
	int count = (encoder_cnt*4000+htim_encoder->Instance->CNT);		
	Wm = (count - re_count)/2000.0f*pi*Fre;							//rad/s,������������/(1Ȧ4000)*2pi/����ʱ��
	Wm = old_Wm * 0.6 + Wm * (1 - 0.6);
	old_Wm = Wm;
	re_count = count;
}